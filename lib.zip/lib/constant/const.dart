import 'package:flutter/widgets.dart';

// ignore: camel_case_types
class wr {
  static Color mainColor = const Color(0xFFFFA451);
}

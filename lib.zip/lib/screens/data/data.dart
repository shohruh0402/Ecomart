import 'package:flutter/material.dart';

List<Color> containerColor = [
  Colors.cyan.shade50,
  Colors.orange.shade50,
  Colors.pink.shade50,
  Colors.purple.shade50,
  Colors.yellow.shade50,
  Colors.blue.shade50,
  Colors.cyan.shade50,
  Colors.orange.shade50,
  Colors.pink.shade50,
  Colors.purple.shade50,
  Colors.yellow.shade50,
  Colors.blue.shade50,
];
List meva = [
  {
    "name": "Apelsin Turkiya",
    "kg": 1,
    "price": 1.79,
    "image":
        "https://pngicon.ru/file/uploads/apelsin.png",
    "description":
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
  },
  
  {
    "name": "Ananas Bonanza",
    "kg": 1,
    "price": 3.49,
    "image":
        "https://www.pngplay.com/wp-content/uploads/6/Pineapple-Slices-PNG.png",
    "description":
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
  },
  {
    "name": "Mandarin Turkiya",
    "kg": 1,
    "price": 1.69,
    "image":
        "https://clipart-best.com/img/mandarin/mandarin-clip-art-17.png",
    "description":
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
  },
  {
    "name": "Kivi Iran",
    "kg": 1,
    "price": 1.79,
    "image":
        "https://www.pngmart.com/files/1/Kiwi-Slice-PNG-File.png",
    "description":
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
  },
  {
    "name": "Organic Bananas",
    "kg": 1,
    "price": 1.49,
    "image":
        "https://static.wixstatic.com/media/2cd43b_f82b6214c0d24f0e9dbf356b782c2207~mv2_d_2517_1767_s_2.png/v1/fill/w_320,h_224,q_90/2cd43b_f82b6214c0d24f0e9dbf356b782c2207~mv2_d_2517_1767_s_2.png",
    "description":
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
  },
  {
    "name": "Green Apples",
    "kg": 1,
    "price": 1.59,
    "image":
        "http://assets.stickpng.com/images/580b57fcd9996e24bc43c127.png",
    "description":
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
  },
];
